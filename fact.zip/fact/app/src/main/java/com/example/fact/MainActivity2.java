package com.example.fact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Bundle b=getIntent().getExtras();
        int n=Integer.parseInt(b.getString("no"));
        long f=1;
        for(int i=n;i>0;i--){
            f=f*i;
        }
        res=findViewById(R.id.res);
        res.setText("fact of " +n+ " is " +f);
    }
}